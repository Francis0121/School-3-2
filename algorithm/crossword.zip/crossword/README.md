crossword
=========

<h1>Solves Crossword.</h1>
<h2> C++ Code to solve Crosswords</h2>
<ul>
  <li> <b>Crossword.cpp </b>- Main source file compile and run no dependencies. </li> 
  <li> *<b>test </b>- Some random test files. </li>
  <li> <b>word.txt </b>- Dictionary File </li>
</ul>
  
Words are taken from a standard dictonary. <br>//Dictionary Search can be significantly speeded by using a TRIE<br>
Just A Complex Graph search with backtracking is applied.<br>
Can be modified to give all solutions.<br>
Thanks To -<br/><b>Dr.Peter Norvig</b> Article on sudoku.<br/>

<h3> Rough Benchmarking</h3>
<h6>Performed Some tests on my Core i5 processor machine</h6>
<ul>
	<li> Average time to solve a 11X11 Matrix 5.400s </li>
	<li> Average time to solve a 7X7 Matrix 2.328s </li>

</ul>
